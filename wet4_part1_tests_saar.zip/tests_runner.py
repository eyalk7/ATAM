#!/usr/bin/python
import os

os.system("javac Cluster.java")

def createTests(file, test_name): #returns num of tests created
    tests_ctr = 0
    is_first = 1
    cur_test = ''
    lines = file.readlines()
    for line in lines:
        if (line[0] == 't'): # start of a new test
            if (is_first):
                is_first = 0
                continue
            else:
                tmp_f = open(test_name + str(tests_ctr), "w")
                tmp_f.write(cur_test)
                tmp_f.close()
                cur_test = ''
                tests_ctr+=1
        else:
            cur_test += line
    tmp_f.close()

    return tests_ctr


def runTests(num_of_tests):
    failed = []
    for i in range(num_of_tests):
        test_num = i
        in_name = "input" + str(test_num)
        exp_name = "expected" + str(test_num)
        actual_name = "actual" + str(test_num)
        cmd = "java Cluster < " + in_name + " > " + actual_name
        os.system(cmd)
        cur_exp_f = open(exp_name, "r")
        cur_actual_f = open(actual_name, "r")
        cur_exp = cur_exp_f.read()
        cur_actual = cur_actual_f.read()
        cur_exp_f.close()
        cur_actual_f.close()
        if (cur_exp != cur_actual):
            print ("Test number " + str(test_num) + " FAILED :(")
            failed.append(test_num)
        else:
            print ("Test number " + str(i) + " PASSED :D")
        
    if (len(failed) == 0):
        print ("YOU PASSED EVERY TEST, can I be your partner next time? <3")
    else:
        print ("You failed " + str(len(failed)) + " tests:")
        print (failed)

def createFilesFromSource(source_name, test_name):
    f = open(source_name, "r")
    tests_created = createTests(f, test_name)
    return tests_created

# create hand-made input files:
tests_ctr_hm = createFilesFromSource("tests_in_hm", "input")
# create hand-made expected files:
createFilesFromSource("tests_expected_hm", "expected")
# run hand-made tests:
runTests(tests_ctr_hm)